use employee
create table Employee_Info(Emp_id int primary key identity,EmpName varchar(25),Kin_Id varchar(10), Email_Id varchar(25),EmpAddress varchar(30),
Phone varchar(10),Dob DateTime,DOJ Datetime, DeptID int ,foreign key(DeptID) references Department(DeptID),ProjID int,
 foreign key(ProjID) references Project(ProjID),RoleID int,Foreign key(RoleID) references EmpRole(RoleID))


drop table Employee_Info

select * from Employee_Info

create table Department(DeptID int Primary key,DeptName varchar(20),DeptDesc varchar(50))

create table Project(ProjID int Primary key,ProjName VARCHAR(30),ProjDesc varchar(50),
DeptId int,foreign key(DeptID) references Department(DeptID))

create table EmpRole(RoleID int primary key,RoleName varchar(20),RoleDesc varchar(50))


use employee
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET Identity_insert Employee_Info ON
go
CREATE PROCEDURE dbo.usp_InsertEmployee
(
@Name VARCHAR(25),
@Kinid varchar(10),
@Email varchar(25),
@Address varchar(30),
@Phone varchar(10),
@Dob DateTime,
@Doj DateTime,
@Deptid int,
@Projid int,
@Roleid int)
AS
begin
INSERT INTO Employee_Info VALUES(@Name,@Kinid,@Email ,@Address,@Phone ,@Dob,@Doj ,@Deptid ,@Projid ,@Roleid )
select * from Employee_Info;
end 
drop procedure  dbo.usp_InsertEmployee
use employee
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE dbo.usp_UpdateEmployee
(


@Name VARCHAR(25),
@Kinid varchar(10),
@Email varchar(25),
@Address varchar(30),
@Phone varchar(10),
@Dob DateTime,
@Doj DateTime,
@Deptid int,
@Projid int,
@Roleid int)
as 
update Employee_Info set EmpName=@Name,Kin_Id=@Kinid,Email_Id=@Email ,EmpAddress=@Address,Phone=@Phone ,Dob=@Dob,DOJ=@Doj ,
DeptID=@Deptid ,ProjID=@Projid ,RoleID=@Roleid where Emp_id=@EmpId
go
use employee
   go
   set  ansi_Nulls on
   go
   set Quoted_Identifier on
    go
   Create PROCEDURE dbo.usp_Searchbyid
   @EmpId int 
   as 
   select * from Employee_Info where Emp_id=@EmpId
   go
   use employee
   go
   set  ansi_Nulls on
   go
   set Quoted_Identifier on
    go
   Create PROCEDURE dbo.usp_Searchbyname
   @EmpName varchar(25) 
   as 
   select * from Employee_Info where EmpName=@EmpName
   go
   use employee
   go
   set  ansi_Nulls on
   go
   set Quoted_Identifier on
    go
   Create PROCEDURE dbo.usp_Searchbyemail
   @Email int 
   as 
   select * from Employee_Info where Email_Id=@Email
   go

   use employee
   SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE dbo.usp_DeleteEmployee

@EmpId int
as
Delete from Employee_Info 
 where Emp_id=@EmpId;
go
use employee
create procedure dbo.usp_DisplayEmployee
as
begin select * from Employee_Info
end