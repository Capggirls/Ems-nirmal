﻿using System;
using System.Runtime.Serialization;

namespace EMSWPFPL
{
    [Serializable]
    internal class DbEntityValidation : Exception
    {
        public DbEntityValidation()
        {
        }

        public DbEntityValidation(string message) : base(message)
        {
        }

        public DbEntityValidation(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected DbEntityValidation(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}