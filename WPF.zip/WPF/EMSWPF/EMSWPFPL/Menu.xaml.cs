﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Runtime.Serialization;
using System.Data.Entity.Validation;

namespace EMSWPFPL
{
    /// <summary>
    /// Interaction logic for Menu.xaml
    /// </summary>
    public partial class Menu : Window
    {
        public Menu()
        {
            InitializeComponent();
        }
        EmployeeEntities1 context;
        EmployeeEntities1 pro;
        Employee_Info prod;
        private void btn_Insert_Click(object sender, RoutedEventArgs e)
        {
            context = new EmployeeEntities1();
            if (txtName.Text == "" || txtId.Text == "")
            {
                MessageBox.Show("Please provide all the details");
            }
            else
            {
                try
                {

                    prod = new Employee_Info();
                    prod.Emp_id = Convert.ToInt32(txtId.Text);
                    prod.EmpName = txtName.Text;
                    prod.Kin_Id = txtKin.Text;
                    prod.Email_Id = txtEmail.Text;
                    prod.EmpAddress = txtaddress.Text;
                    prod.Phone = txtPhone.Text;
                    prod.Dob = dp_DOB.DisplayDate;
                    prod.DOJ = dp_DOJ.DisplayDate;
                    prod.DeptID = Convert.ToInt32(txt_deptId.Text);
                    prod.ProjID = Convert.ToInt32(txt_PtId.Text);
                    prod.RoleID = Convert.ToInt32(txt_RoleId.Text);

                    context.Employee_Info.Add(prod);//Adds the employee object to the entity set
                    context.SaveChanges();//Commits the change to the database;



                    MessageBox.Show("Employee Record Inserted");
                    //ResetFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    prod = null;
                }
                dgEmployee.DataContext = context.Employee_Info.ToList();
            }

        }

        private void Btn_Delete_Click(object sender, RoutedEventArgs e)
        {

            //pro = new EmployeeEntities1();
            //int Emp_Id = Convert.ToInt32(txt_Id.Text);
            //var product = pro.Employee_Info.Where(x => x.Emp_id == Emp_Id).SingleOrDefault();
            //if (product != null)
            //{
            //    pro.Employee_Info.Remove(product);
            //    pro.SaveChanges();
            //}
            //MessageBox.Show("Deleted");
        }

        private void Btn_searchid_Click(object sender, RoutedEventArgs e)
        {
            //context = new EmployeeEntities1();
            //int id = Convert.ToInt32(txtid.Text);
            ////Employee_Info prod = context.Employee_Info.Where(x => x.Emp_id == id).SingleOrDefault();
            //dgEmployee1.DataContext = context.Employee_Info.Where(x => x.Emp_id == id).ToList();
        }

        private void Cb_Dept_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
    
    

