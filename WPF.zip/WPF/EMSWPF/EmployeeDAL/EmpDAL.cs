﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using EmployeeException;
using EMSWPFPL;

namespace EmployeeDAL
{
    public class EmpDAL
    {
        public static SqlCommand CreateCommand()
        {
            SqlCommand cmd = null;

            try
            {
                string sqlConnectString = ConfigurationManager.ConnectionStrings["EmployeeEntities"].ConnectionString;

                //  string s= @"Data Source =DESKTOP-F04QEU9; Initial Catalog = training1; Integrated Security = true; ";
                SqlConnection con = new SqlConnection();
                // con.ConnectionString = @"Data Source=SHRIYA-PC;Database=Training; integrated security=true;";
                con.ConnectionString = sqlConnectString;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return cmd;
        }
        public static int InsertCustomer(Employee_Info newEmp)
        {
            int EmpInserted = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "usp_InsertCustomer";


                cmd.Parameters.AddWithValue("@Name", newEmp.EmpName);
                cmd.Parameters.AddWithValue("@Kinid", newEmp.Kin_Id);
                cmd.Parameters.AddWithValue("@Email", newEmp.Email_Id);
                cmd.Parameters.AddWithValue("@Address", newEmp.EmpAddress);
                cmd.Parameters.AddWithValue("@Phone", newEmp.Phone);
                cmd.Parameters.AddWithValue("@Dob", newEmp.Dob);
                cmd.Parameters.AddWithValue("@Doj", newEmp.DOJ);
                cmd.Parameters.AddWithValue("@Deptid", newEmp.DeptID);
                cmd.Parameters.AddWithValue("@Projid", newEmp.ProjID);
                cmd.Parameters.AddWithValue("@Roleid", newEmp.RoleID);

                cmd.Connection.Open();
                EmpInserted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return EmpInserted;
        }
    }
}
