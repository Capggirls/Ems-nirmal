﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeException
{
    public class Empexception:ApplicationException

    {
        public Empexception()
   : base()
        { }

        public Empexception(string message)
            : base(message)
        { }
    }
}
