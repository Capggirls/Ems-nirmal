﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using EmployeeException;
using EMSWPFPL;
using EmployeeDAL;

namespace EmployeeBL
{
    public class EmpBL
    {
        public static bool ValidateEmployee(Employee_Info Employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
            if (Employee.Emp_id==0)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Id is required cannot be blank");
            }
           
            if (Employee.EmpName == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee name required");
            }
            else if (!Regex.IsMatch(Employee.EmpName, "^[A-Z][a-z]"))
            {
                sb.Append("Employee name should start with Capital letter and it" + "should have alphabetsonly\n");
                validEmployee = false;
            }
            if (Employee.Kin_Id == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Kin Id is required cannot be blank");
            }
            else if (!Regex.IsMatch(Employee.Kin_Id, @"[0-9]{5}-[A-Z]{2}"))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + " Employee Kin Required");
            }
            if (Employee.Email_Id == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee email ID required");
            }
            else if (!Regex.IsMatch(Employee.Email_Id, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"))
            {
                sb.Append("Ivalid email ID");
                validEmployee = false;
            }
            if (Employee.EmpAddress == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee address required");
            }
            else if (!Regex.IsMatch(Employee.EmpAddress, "^[A-Z][a-z]"))
            {
                sb.Append("Address should start with Capitl letter and it" + "should have alphabetsonly\n");
                validEmployee = false;
            }

            if (Employee.Phone.Length < 10)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Required 10 digit contact number");
            }
            else if (!Regex.IsMatch(Employee.Phone, "[7-9][0-9]{9}$"))
            {
                sb.Append("Phone numbershould start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                validEmployee = false;
            }
            if (Employee.Dob.ToString()=="")
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + " Date Of Birth cannot be null");
            }
            if (Employee.DOJ.ToString() == "")
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + " Date Of Joining cannot be null");
            }

            if (Employee.DOJ >= System.DateTime.Now)   //Joined date should be less than current date
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Date of Joining should be before current date ");
            }
            if (Employee.DeptID == 0)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Id is required cannot be blank");
            }
            if (Employee.ProjID == 0)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Id is required cannot be blank");
            }
            if (Employee.RoleID == 0)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Id is required cannot be blank");
            }

            if (validEmployee == false)
                throw new EmployeeException.Empexception(sb.ToString());
            return validEmployee;
        }
        public static int InsertCustomer(Employee_Info newCust)
        {
            int custInserted = 0;

            try
            {
                if (ValidateEmployee(newCust))
                {
                    custInserted = EmpDAL.InsertCustomer(newCust);
                }
                else
                    throw new Empexception("Customer data is invalid");
            }
            catch (Empexception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custInserted;
        }

        //public static int UpdateCustomer(Customer custToBeUpdated)
        //{
        //    int custUpdated = 0;

        //    try
        //    {
        //        if (ValidateCustomer(custToBeUpdated))
        //        {
        //            custUpdated = CustomerDAL.UpdateCustomer(custToBeUpdated);
        //        }
        //        else
        //        {
        //            throw new CustomerException("Invalid Customer data for updation");
        //        }
        //    }
        //    catch (CustomerException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return custUpdated;
        //}

        //public static int DeleteCustomer(int custID)
        //{
        //    int custDeleted = 0;

        //    try
        //    {
        //        custDeleted = CustomerDAL.DeleteCustomer(custID);
        //    }
        //    catch (CustomerException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return custDeleted;
        //}

        //public static Customer SearchCustomer(int custID)
        //{
        //    Customer custSearched = null;

        //    try
        //    {
        //        custSearched = CustomerDAL.SearchCustomer(custID);
        //    }
        //    catch (CustomerException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return custSearched;
        //}

        //public static DataTable DisplayCustomer()
        //{
        //    DataTable dtCust = null;

        //    try
        //    {
        //        dtCust = CustomerDAL.DisplayCustomer();
        //    }
        //    catch (CustomerException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return dtCust;
        //}
    //}
}
}
